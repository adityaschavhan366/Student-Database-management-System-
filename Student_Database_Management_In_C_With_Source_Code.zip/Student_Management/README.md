# Student_Management_System
Simple student management database system in C with File I/O 

This is simple student database management system in C programme. In this mini project user can 
<br/>
Create a student account
<br/>
Display all students information
<br/>
Update a student's information
<br/>
Delete a student's account
<br/>
Search a student's information or can see depertment wise students information.




